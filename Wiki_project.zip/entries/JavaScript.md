# JavaScript

JavaScript frameworks are tools designed to speed up development and organize code used to build modern web apps.
