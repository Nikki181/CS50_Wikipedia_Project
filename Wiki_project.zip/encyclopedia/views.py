import markdown2
import random
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.urls import reverse
from . import util

pagelist = util.list_entries()

def index(request):
   return render(request, "encyclopedia/index.html", {
         "entries": util.list_entries()
    })

def wiki(request, title):
    pagelist = util.list_entries()
    if title in pagelist:
        content = util.get_entry(title)
        
        return render(request, "encyclopedia/page.html", {
            "title": title,
            "content": markdown2.markdown(content)
        })
        
    else:
        return render(request, "encyclopedia/error.html", { 
            'error_message': 'Sorry, Page could not found!!'
        })

def create(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')  
        alreadyexist =util.get_entry(title)    
        if alreadyexist == None:
            util.save_entry(title, content)
            return redirect(index)
        else:
             return render(request, "encyclopedia/create.html", {
                'exists': True
            })
    return render(request, "encyclopedia/create.html", {
        'exists': False

    })

def edit(request,title):
    content=util.get_entry(title)
    if request.method=="GET":
        return render(request,"encyclopedia/edit.html",{
            'title':title,
            'content':content
        })
    
    if request.method == "POST":
        content=request.POST.get('content')
        util.save_entry(title, content)
        return redirect(wiki,title)

    
def search(request):
    searchitem=request.GET['q']
    content=util.get_entry(request.GET['q'])
    if util.get_entry(searchitem):  
        return render(request, "encyclopedia/page.html", {
            "title": request.GET['q'],
            "content": markdown2.markdown(content)  
        })
    else:
        searchlist = []
        for entry in pagelist:
            if searchitem.lower() in entry.lower():
                searchlist.append(entry)
            
        if len(searchlist)==0:
            return render(request, "encyclopedia/error.html", {
                'error_message': f'Sorry , No results found for ' + request.GET['q']
            })
        return render(request, "encyclopedia/search.html", {
            'entries': searchlist
        })

def randompage(request):    
    r = random.randint(0, len(pagelist)-1)
    title = pagelist[r]

    return redirect(wiki, title=title)

            

    




